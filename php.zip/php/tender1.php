<?php
session_start();
include "connect.php";

$value_year = $_POST['postname'];

$select = mysqli_query($mysqli, "select * from seelog_ocds_data where ocds_year = '$value_year'") or die("ini ang error : " . mysqli_error($mysqli));
$check = mysqli_num_rows($select);
if($check!=0){
	
	 echo $content = '<table id="featured-datatable" class="table table-striped">
	<thead>
		<tr>
			<th>OCID</th>
			<th title="Tender Title">Title</th>
			<th title="Allocated Budget">Budget(PHP)</th>
			<th title="Tender Winner Contractor">Contractor/Supplier</th>
			<th>Rating</th>
		</tr>
	</thead>
	<tbody>';
		foreach($select as $row){
	 
		echo '<tr>
			<td><a href="#">' . $row["ocds_ocid"] .' </a></td>
			<td>'. $row["ocds_title"] .'</td>
			<td>'. number_format($row["ocds_allocated_budget"],2) .'</td>
			<td>'. $row["ocds_contractor"] .'</td>
			<td><span class="label label-success">';
			if($row["rating"]==1){ 
				echo '<i class="fa fa-star"></i>';
			}
			if($row["rating"]==1.5){ 
				echo '<i class="fa fa-star"></i>
				<i class="fa fa-star-half-o"></i>';
			}
			if($row["rating"]==2){
				echo '<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>';
			}
			if($row["rating"]==2.5){
				echo '<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star-half-o"></i>';
			}
			if($row["rating"]==3){
				echo '<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>';
			}  
			if($row["rating"]==3.5){ 
				echo '<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star-half-o"></i>';
			}
			if($row["rating"]==4){
				echo '<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>';
			}
			if($row["rating"]==4.5){
				echo '<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star-half-o"></i>';
			}
			if($row["rating"]==5){
				echo '<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>
				<i class="fa fa-star"></i>';
			}
			
			echo '</span></td>
		</tr>';
	 } 
	 echo '
			</tbody>
		</table>';
}else{
	
	 echo $content = '<table id="featured-datatable" class="table table-striped">
		<thead>
			<tr>
				<th>OCID</th>
				<th title="Tender Title">Title</th>
				<th title="Allocated Budget">Budget(PHP)</th>
				<th title="Tender Winner Contractor">Contractor/Supplier</th>
				<th>Rating</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td><a href="#">No Data</a></td>
				<td>No Data</td>
				<td>No Data</td>
				<td>No Data</td>
				<td>No Data</td>
			</tr>';
		 
		echo '
		</tbody>
	</table>';
}


?>
	
	<link rel="stylesheet" href="../assets/vendor/datatables/css-main/jquery.dataTables.min.css">
	<link rel="stylesheet" href="../assets/vendor/datatables/css-bootstrap/dataTables.bootstrap.min.css">
	<script src="../assets/vendor/datatables/js-main/jquery.dataTables.min.js"></script>
	<script src="../assets/vendor/datatables/js-bootstrap/dataTables.bootstrap.min.js"></script>
	<script>
	$('#featured-datatable').dataTable({
			sDom: "<'row'<'col-sm-6'l><'col-sm-6'f>r>t<'row'<'col-sm-6'i><'col-sm-6'p>>",
		});
	</script>