<?php
session_start();
$success         = array();      // array to hold validation errors
$data           = array();      // array to pass back data

$target_dir = "json/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));


// Allow certain file formats
if($imageFileType != "json" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
		$file = basename( $_FILES["file"]["name"]);
		
		$str = file_get_contents('json/'.$file.'');

		$json = json_decode($str, true);

		$ocid = $json[0]['ocid'];
		if($ocid!=null){
			$final_data = json_encode($json,JSON_PRETTY_PRINT);
			if(file_put_contents('json/'.$ocid.'.json', $final_data))
			{
				unlink('json/'.$file.'');
				echo $ocid;
				$success['ocid'] = $ocid;
				$data['success']  = $ocid;
				
			}
		}else{
			unlink('json/'.$file.'');
			echo "0";
		}
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>