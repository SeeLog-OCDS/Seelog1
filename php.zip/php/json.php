<?php
include "connect.php";
$ocid = $_POST['ocid'];
$str = file_get_contents('json/'.$ocid.'.json');
$prompt = $_POST['prompt'];
$inaccurate = $_POST['inaccurate'];
$damaged = $_POST['damaged'];
$incomplete = $_POST['incomplete'];
$late = $_POST['late'];
$prompt = 100-$prompt;
$total = ($prompt+$inaccurate+$damaged+$incomplete+$late)/5;

$json = json_decode($str, true);

$loop = count($json);

for($i=0;$i<$loop;$i++){
	$metadata_ocid[$i] = $json[$i]['ocid'];
	$metadata_title[$i] = $json[$i]['tender']['title'];
	$metadata_date[$i] = substr($json[$i]['date'],0,4);
	$metadata_contractor[$i] = $json[$i]['awards']['suppliers']['name']; 
	$metadata_budgets[$i] = $json[$i]['planning']['budget']['amount']['amount'];
	$metadata_amount[$i] = $json[$i]['contracts']['value']['amount']; 
	
	$contractor_pass = md5($metadata_contractor[$i]);
	
	$select = mysqli_query($mysqli, "select * from seelog_ocds_data where ocds_ocid = '$metadata_ocid[$i]'") or die("ini ang error : " . mysqli_error($mysqli));
	$check = mysqli_num_rows($select);
	if($check==0){
		
		$contractor = mysqli_query($mysqli, "select * from seelog_ocds_account where account_username = '$metadata_contractor[$i]'") or die("ini ang error : " . mysqli_error($mysqli));
		$contractor_count = mysqli_num_rows($contractor);
		
		if($contractor_count==0){
			$contractor = mysqli_query($mysqli, "INSERT INTO `seelog_ocds_account`(`account_username`, `account_password`, `account_avatar`, `priv_code`) VALUES ('$metadata_contractor[$i]','$contractor_pass','contractor.png','contract01')") or die("ini ang error : " . mysqli_error($mysqli));
		}
		
		$query = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_data`(`ocds_ocid`, `ocds_title`, `ocds_year`, `ocds_contractor`, `ocds_allocated_budget`,`ocds_amount`) VALUES ('$metadata_ocid[$i]','$metadata_title[$i]','$metadata_date[$i]','$metadata_contractor[$i]','$metadata_budgets[$i]','$metadata_amount[$i]')") or die("Ini ang error : " . mysqli_error($mysqli));
		
		$query1 = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_supplier_rating`(`ocds_ocid`, `ocds_contractor`, `promptness`, `ProductAccuracy`, `QualityOfProducts`, `InFullDelivery`, `OnTimeDelivery`,`total`) VALUES ('$ocid','$metadata_contractor[$i]','$prompt','$inaccurate','$damaged','$incomplete','$late','$total')") or die("Ini ang error : " . mysqli_error($mysqli));
		$link = "tenderdetails.php";
		
		$query2 = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_recent`(`link`, `status`, `description`,`category`,`name`,`pic`) VALUES ('$link','0','LGU Legazpi has uploaded an OCDS file','uploaded','LGU Legazpi','legazpi.png')") or die("Ini ang error : " . mysqli_error($mysqli));
		
		echo "<script>location.href='../index.php'</script>";
	}
	else{
		$query = mysqli_query($mysqli,"UPDATE `seelog_ocds_data` SET `ocds_title`='$metadata_title[$i]',`ocds_year`='$metadata_date[$i]',`ocds_contractor`='$metadata_contractor[$i]',`ocds_allocated_budget`='$metadata_budgets[$i]', `ocds_amount`='$metadata_amount[$i]' WHERE ocds_ocid = '$metadata_ocid[$i]'") or die("ini ang error : " . mysqli_error($mysqli));
		
		$query1 = mysqli_query($mysqli,"UPDATE `seelog_ocds_supplier_rating` SET `ocds_contractor`='$metadata_contractor[$i]',`promptness`='$prompt',`ProductAccuracy`='$inaccurate',`QualityOfProducts`='$damaged',`InFullDelivery`='$incomplete',`OnTimeDelivery`='$late',`total`='$total' WHERE ocds_ocid = '$metadata_ocid[$i]'") or die("ini ang error : " . mysqli_error($mysqli));
		$link = "tenderdetails.php";
		$query2 = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_recent`(`link`, `status`, `description`,`category`,`name`,`pic`) VALUES ('$link','0','LGU Legazpi has updated an OCDS file','update','LGU Legazpi','legazpi.png')") or die("Ini ang error : " . mysqli_error($mysqli));
		echo "<script>location.href='../index.php'</script>";
	}
}





?>