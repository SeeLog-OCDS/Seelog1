<?php
	include "../connect.php";

	$post_id = $_POST['post_id'];
	$parent_comment_id = $_POST['parent_comment_id'];
	$comment_sender_name = $_POST['comment_sender_name'];
	$comment = $_POST['comment'];
	$date = date('Y-m-d H:i:s');


	
	$query = mysqli_query($mysqli, "	INSERT INTO `reply` (`id`, `post_id`, `parent_comment_id`, `comment_sender_name`, `comment`, `date`) VALUES (NULL, '$post_id', '$parent_comment_id', '$comment_sender_name', '$comment', '$date')");

	if (! $query) {
		$query = mysqli_error($mysqli);
	}
	echo $query;
?>