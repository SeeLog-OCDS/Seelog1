<?php
include "connect.php";
session_start();
$username = mysqli_real_escape_string($mysqli,$_POST['username']);
$password = mysqli_real_escape_string($mysqli,$_POST['password']);

echo $pass = md5($password);

$sql = mysqli_query($mysqli, "select * from seelog_ocds_account where account_username = '$username' and account_password = '$pass'") or die("Error : " . mysqli_error($mysqli));
$check = mysqli_num_rows($sql);

if($check==1){
	foreach($sql as $row){
		$_SESSION['username'] = $row['account_username'];
		$_SESSION['priv'] = $row['priv_code'];
		$_SESSION['pic'] = $row['account_avatar'];
	}
	if($_SESSION['priv']=='lgu01'){
		header("Location: ../index.php");
	}else{
		if($_SESSION['priv']=='user01'){
			header("Location: ../freedomwall.php");
		}else if($_SESSION['priv']=='lgu01'){
			header("Location: ../admin/index.php");
		}
	}
	
}else{
	header("Location: ../page-login.html");
}
?>