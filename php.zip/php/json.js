function input(){
	var input = document.getElementById("file");
	var file = input.value.split(".");
	var fileName = file[file.length-1];
	
	if(fileName!="json"){
		document.getElementById("btn").disabled=true;
	}else{
		document.getElementById("btn").disabled=false;
	}
	
}
	$(function() {
		

		$('#btn').on('click', function() {
			var file_data = $('#file').prop('files')[0];   
    var form_data = new FormData();                  
    form_data.append('file', file_data);              
     $.ajax({
        url: 'php/upload.php', // point to server-side PHP script 
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,                         
        type: 'post',
        success: function(php_script_response){
			if(php_script_response!='0'){
			   swal({
					title: 'OCDS FILE',
					text: "To completely upload your file please rate first",
					type: 'info',
					confirmButtonColor: '#3085d6',
					confirmButtonText: 'Okay'
				}).then(function() {
					 $('#blog-post-popup').modal('show'),
					 document.getElementById("ocid_hidden").value=php_script_response,
					 $("#myButton").click();
				}).catch(swal.noop); 
			}else{
				swal({
					title: 'JSON File is not an OCDS format',
					text: "Please try again",
					type: 'error',
					confirmButtonColor: '#41B314',
					confirmButtonText: 'Okay'
				}).then(function() {
					location.href='index.php';
				}).catch(swal.noop); 
			}
			// display response from the PHP script, if any
        },
		error: function(php_script_response){
           swal({
				title: 'OCDS file not uploaded!',
				text: "Please try again",
				type: 'error',
				confirmButtonColor: '#00aaff',
				confirmButtonText: 'Okay'
			}).then(function() {
				location.href='index.php';
			}).catch(swal.noop); // display response from the PHP script, if any
        }
     });
		});
		
	
	$('#json_submit').submit(function(event) {
			
        var formData = {
           'pa'              : $('#pa').val(),
            'ocid'              : $('#ocid').val(),
            'sup'              : $('#sup').val(),
            'qp'              : $('#qp').val(),
            'fd'              : $('#fd').val(),
            'td'              : $('#td').val(),
            'p'    			  : $('#p').val()
        };

        // process the form
		$.ajax({
			type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
			url         : 'php/rate_sup.php', // the url where we want to POST
			data        : formData, // our data object
			dataType    : 'json' // what type of data do we expect back from the server
		})
		// using the done promise callback
		.done(function(data) {

        // log data to the console so we can see
        console.log(data);

        // here we will handle errors and validation messages
        if ( ! data.success) {

        } else {
			location.href="index.php";

        }
            });

        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
    });
	
	});
	
	