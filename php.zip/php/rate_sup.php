<?php
include "connect.php";
session_start();

$errors         = array();      // array to hold validation errors
$data           = array();      // array to pass back data


		$ocid=$_POST['ocid'];
		$pa= $_POST['pa'];
		$qp= $_POST['qp'];
		$fd= $_POST['fd'];
		$td= $_POST['td'];
		$p= $_POST['p'];
		$sup_name= $_POST['sup'];
		$a = $pa*10;
		$b = $qp*10;
		$c = $td*10;
		$d = $fd*10;
		$e = $p*10;
		$pass = md5($sup_name);
		
		$select_contractor = mysqli_query($mysqli,"select * from seelog_ocds_account where account_email = '$sup_name' or account_username = '$sup_name'") or die("Error: " . mysqli_error($mysqli));
		
		$count_conntractor = mysqli_num_rows($select_contractor);
		
		if($count_conntractor==0){
		$insert_account = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_account`(`account_fname`, `account_lname`, `account_email`, `account_username`, `account_password`, `account_avatar`, `account_cover`, `priv_code`, `show_username`, `friends`, `post`, `flagged`) VALUES (' ',' ','$sup_name','$sup_name','$pass','contractor.png','contractor.png','contract01','0','0','0','0')") or die("Error creating account: " . mysqli_error($mysqli));
		
		}
		
		
		
		$str = file_get_contents('json/'.$ocid.'.json');

		$json = json_decode($str, true);

		$ocds_title = $json[0]['tender']['title'];
		$ocds_year = substr($json[0]['date'],0,4);
		$ocds_budget = $json[0]['planning']['budget']['amount']['amount'];
		$ocds_amount = $json[0]['contracts']['value']['amount'];;
		$ocds_supplier_win_name = $json[0]['awards']['suppliers']['name'];
		$ocds_supplier_win_id = $json[0]['awards']['suppliers']['id'];
		
		$select_ocds_data = mysqli_query($mysqli,"select * from seelog_ocds_data where ocds_ocid = '$ocid'");
		
		$count_select_ocds_data = mysqli_num_rows($select_ocds_data);
		
		if($count_select_ocds_data==0){
			$insert_ocds_data = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_data`(`ocds_ocid`, `ocds_title`, `ocds_year`, `ocds_contractor`, `ocds_allocated_budget`, `ocds_amount`) VALUES ('$ocid','$ocds_title','$ocds_year','$sup_name','$ocds_budget','$ocds_amount')") or die("Error: " . mysqli_error($mysqli));
		}else{
			foreach($select_ocds_data as $row){
				$ocid_history = $row['ocds_ocid'];
				$title_date = $row['date_shared'];
				$title_history = $row['ocds_title'];
				$year_history = $row['ocds_year'];
				$sup_history = $row['ocds_contractor'];
				$budget_history = $row['ocds_allocated_budget'];
				$amount_history = $row['ocds_amount'];
				
				$insert_ocds_data_history = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_data_history`(`ocds_ocid`,`date_shared`, `ocds_title`, `ocds_year`, `ocds_contractor`, `ocds_allocated_budget`, `ocds_amount`) VALUES ('$ocid_history','$title_date','$title_history','$year_history','$sup_history','$budget_history','$amount_history')") or die("Error: " . mysqli_error($mysqli));
			}
				$update_ocds_data = mysqli_query($mysqli,"UPDATE `seelog_ocds_data` SET `ocds_title`='$ocds_title',`ocds_year`='$ocds_year',`ocds_contractor`='$sup_name',`ocds_allocated_budget`='$ocds_budget',`ocds_amount`='$ocds_amount' WHERE ocds_ocid = '$ocid'");
			
		}
		
		$final_data = json_encode($json);
		$avg = ($pa+$qp+$fd+$td+$p)/5;
		$total = ($avg*0.1)*100;
		  if ( ! empty($errors)) {

        // if there are items in our errors array, return those errors
        $data['success'] = false;
        $data['errors']  = $errors;
    } else {

		$select_rating = mysqli_query($mysqli,"select * from seelog_ocds_supplier_rating where ocds_ocid = '$ocid'");
		$count_select_rating = mysqli_num_rows($select_rating);
		$select_contract = mysqli_query($mysqli,"select * from seelog_ocds_supplier_rating where ocds_contractor = '$sup_name'");
		$count_select_contract = mysqli_num_rows($select_contract);
		
		if($count_select_rating==0){
			$insert_rating = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_supplier_rating`(`ocds_ocid`, `ocds_contractor`, `promptness`, `ProductAccuracy`, `QualityOfProducts`, `InFullDelivery`, `OnTimeDelivery`, `total`,`total_rating`,`year`) VALUES ('$ocid','$sup_name','$p','$pa','$qp','$fd','$td','$total','$total','$ocds_year')") or die("Error: " . mysqli_error($mysqli));
			
			$insert_ratings = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_ratings`(`ocds_contractor`, `pa`, `qp`, `fd`, `td`, `p`, `total`) VALUES ('$sup_name','$a','$b','$d','$c','$e','$total')") or die("Error: " . mysqli_error($mysqli));
		}
		else{
			foreach($select_rating as $row){
				$ocds_ocid = $row['ocds_ocid'];
				$ocds_contractor = $row['ocds_contractor'];
				$promptness = $row['promptness'];
				$ProductAccuracy = $row['ProductAccuracy'];
				$QualityOfProducts = $row['QualityOfProducts'];
				$InFullDelivery = $row['InFullDelivery'];
				$OnTimeDelivery = $row['OnTimeDelivery'];
				$totals = $row['total'];
				$total_rating = $row['total_rating'];
				
				$insert_rating = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_supplier_rating_history`(`ocds_ocid`, `ocds_contractor`, `promptness`, `ProductAccuracy`, `QualityOfProducts`, `InFullDelivery`, `OnTimeDelivery`, `total`,`total_rating`,`year`) VALUES ('$ocds_ocid','$ocds_contractor','$promptness','$ProductAccuracy','$QualityOfProducts','$InFullDelivery','$OnTimeDelivery','$totals','$total_rating','$ocds_year')") or die("Error: " . mysqli_error($mysqli));
			}
			$update_rating = mysqli_query($mysqli,"UPDATE `seelog_ocds_supplier_rating` SET  `ocds_contractor`='$sup_name',`promptness`='$p',`ProductAccuracy`='$pa',`QualityOfProducts`='$qp',`InFullDelivery`='$fd',`OnTimeDelivery`='$td',`total`='$total', `year` = '$ocds_year' WHERE ocds_ocid = '$ocid'") or die("Error: " . mysqli_error($mysqli));
			
			$update_ratings = mysqli_query($mysqli,"UPDATE `seelog_ocds_ratings` SET `pa`='$a',`qp`='$b',`fd`='$d',`td`='$c',`p`='$e',`total`='$total' WHERE ocds_contractor = '$sup_name'") or die("Error: " . mysqli_error($mysqli));
			


		}
		if($count_select_contract>1){
		$count_bidders = mysqli_query($mysqli,"select sum(total) as totals,sum(ProductAccuracy) as pa,sum(QualityOfProducts) as qp,sum(OnTimeDelivery) as td,sum(InFullDelivery) as fd,sum(promptness) as p,ocds_contractor from seelog_ocds_supplier_rating group by ocds_contractor order by totals asc") or die("error: " . mysqli_error($mysqli));
			$counter_bidders = mysqli_num_rows($count_bidders);
			
		if($counter_bidders !=0){
			foreach($count_bidders as $row){
				$seeloog_contractor = $row['ocds_contractor'];
				$counting_bidders = mysqli_query($mysqli,"select * from seelog_ocds_supplier_rating where ocds_contractor = '$seeloog_contractor'") or die("error: " . mysqli_error($mysqli));
				$counts_bidders = mysqli_num_rows($counting_bidders);
				$pa_rating = ($row['pa'] / $counts_bidders)*10;
				$qp_rating = ($row['qp'] / $counts_bidders)*10;
				$td_rating = ($row['td'] / $counts_bidders)*10;
				$fd_rating = ($row['fd'] / $counts_bidders)*10;
				$p_rating = ($row['p'] / $counts_bidders)*10;
				$rating = $row['totals'] / $counts_bidders;
				
				$update_ratings = mysqli_query($mysqli,"UPDATE `seelog_ocds_ratings` SET `pa`='$pa_rating',`qp`='$qp_rating',`fd`='$fd_rating',`td`='$td_rating',`p`='$p_rating',`total`='$rating' WHERE ocds_contractor = '$seeloog_contractor'") or die("Error: " . mysqli_error($mysqli));
				
				$update_rating = mysqli_query($mysqli,"UPDATE `seelog_ocds_supplier_rating` SET `total_rating` = '$rating' where ocds_contractor = '$seeloog_contractor'") or die("Error: " . mysqli_error($mysqli));
			}
		}
		}
		$select_supplier_winner_contracted = mysqli_query($mysqli,"SELECT * FROM `seelog_ocds_suppliers_contracted` WHERE seelog_ocds_supplier_id = '$ocds_supplier_win_id' and year = '$ocds_year'") or die("Error: " . mysqli_error($mysqli));
			$select_supplier_winner_count_contracted = mysqli_num_rows($select_supplier_winner_contracted);
		
		if($select_supplier_winner_count_contracted==0){
			$insert_supplier_winner = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_suppliers_contracted`(`seelog_ocds_supplier_id`, `supplier_name`, `category`,`year`) VALUES ('$ocds_supplier_win_id','$ocds_supplier_win_name','Goods','$ocds_year')") or die("Error: " . mysqli_error($mysqli));
		}
		
		$select_supplier_winner = mysqli_query($mysqli,"SELECT * FROM `seelog_ocds_suppliers` WHERE seelog_ocds_supplier_id = '$ocds_supplier_win_id' and year = '$ocds_year'") or die("Error: " . mysqli_error($mysqli));
			$select_supplier_winner_count = mysqli_num_rows($select_supplier_winner);
		
		if($select_supplier_winner_count==0){
			$insert_supplier_winner = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_suppliers`(`seelog_ocds_supplier_id`, `supplier_name`, `category`,`year`) VALUES ('$ocds_supplier_win_id','$ocds_supplier_win_name','Goods','$ocds_year')") or die("Error: " . mysqli_error($mysqli));
		}
		$ocds_tenderers_count = count($json[0]['tender']['tenderers']);
		for($i=0;$i<$ocds_tenderers_count;$i++){
			$ocds_tenderers_name[$i] = $json[0]['tender']['tenderers'][$i]['name'];
			$ocds_tenderers_id[$i] = $json[0]['tender']['tenderers'][$i]['id'];
			
			
			$select_supplier[$i] = mysqli_query($mysqli,"SELECT * FROM `seelog_ocds_suppliers` WHERE seelog_ocds_supplier_id = '$ocds_tenderers_id[$i]' and year = '$ocds_year'") or die("Error: " . mysqli_error($mysqli));
			$select_supplier_count[$i] = mysqli_num_rows($select_supplier[$i]);
			
			if($select_supplier_count[$i]==0){
				$insert_supplier = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_suppliers`(`seelog_ocds_supplier_id`, `supplier_name`, `category`,`year`) VALUES ('$ocds_tenderers_id[$i]','$ocds_tenderers_name[$i]','Goods','$ocds_year')") or die("Error: " . mysqli_error($mysqli));
			}
		}
		
        // show a message of success and provide a true success variable
         $data['success'] = true;
        $data['message'] = 'Success!';
	$_SESSION['success'] = 1;
	$_SESSION['ocid'] = $ocid;
	}
    // return all our data to an AJAX call
    echo json_encode($data);
   
	
	?>