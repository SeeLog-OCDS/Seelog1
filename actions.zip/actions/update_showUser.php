<?php
include "connect.php";
session_start();

$username = $_SESSION['username'];
$user = $_GET['user'];
$update = mysqli_query($mysqli, "UPDATE `seelog_ocds_account` SET `show_username`='$user' WHERE account_username = '$username'");

$_SESSION['show'] = $user;

header("Location: ../freedomwall.php");
?>