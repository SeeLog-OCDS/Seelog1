
function pa10(){
	document.getElementById('pa').value=10;
}
function pa9(){
	document.getElementById('pa').value=9;
}
function pa8(){
	document.getElementById('pa').value=8;
}
function pa7(){
	document.getElementById('pa').value=7;
}
function pa6(){
	document.getElementById('pa').value=6;
}
function pa5(){
	document.getElementById('pa').value=5;
}
function pa4(){
	document.getElementById('pa').value=4;
}
function pa3(){
	document.getElementById('pa').value=3;
}
function pa2(){
	document.getElementById('pa').value=2;
}
function pa1(){
	document.getElementById('pa').value=1;
}

function qp10(){
	document.getElementById('qp').value=10;
}
function qp9(){
	document.getElementById('qp').value=9;
}
function qp8(){
	document.getElementById('qp').value=8;
}
function qp7(){
	document.getElementById('qp').value=7;
}
function qp6(){
	document.getElementById('qp').value=6;
}
function qp5(){
	document.getElementById('qp').value=5;
}
function qp4(){
	document.getElementById('qp').value=4;
}
function qp3(){
	document.getElementById('qp').value=3;
}
function qp2(){
	document.getElementById('qp').value=2;
}
function q1(){
	document.getElementById('qp').value=1;
}


function fd10(){
	document.getElementById('fd').value=10;
}
function fd9(){
	document.getElementById('fd').value=9;
}
function fd8(){
	document.getElementById('fd').value=8;
}
function fd7(){
	document.getElementById('fd').value=7;
}
function fd6(){
	document.getElementById('fd').value=6;
}
function fd5(){
	document.getElementById('fd').value=5;
}
function fd4(){
	document.getElementById('fd').value=4;
}
function fd3(){
	document.getElementById('fd').value=3;
}
function fd2(){
	document.getElementById('fd').value=2;
}
function fd1(){
	document.getElementById('fd').value=1;
}

function td10(){
	document.getElementById('td').value=10;
}
function td9(){
	document.getElementById('td').value=9;
}
function td8(){
	document.getElementById('td').value=8;
}
function td7(){
	document.getElementById('td').value=7;
}
function td6(){
	document.getElementById('td').value=6;
}
function td5(){
	document.getElementById('td').value=5;
}
function td4(){
	document.getElementById('td').value=4;
}
function td3(){
	document.getElementById('td').value=3;
}
function td2(){
	document.getElementById('td').value=2;
}
function td1(){
	document.getElementById('td').value=1;
}

function p10(){
	document.getElementById('p').value=10;
}
function p9(){
	document.getElementById('p').value=9;
}
function p8(){
	document.getElementById('p').value=8;
}
function p7(){
	document.getElementById('p').value=7;
}
function p6(){
	document.getElementById('p').value=6;
}
function p5(){
	document.getElementById('p').value=5;
}
function p4(){
	document.getElementById('p').value=4;
}
function p3(){
	document.getElementById('p').value=3;
}
function p2(){
	document.getElementById('p').value=2;
}
function p1(){
	document.getElementById('p').value=1;
}