<?php
include "connect.php";
session_start();

$errors         = array();      // array to hold validation errors
$data           = array();      // array to pass back data

// validate the variables ======================================================
    // if any of these variables don't exist, add an error to our $errors array
	
		$username= mysqli_real_escape_string($mysqli,$_POST['username']);
		$log_password= mysqli_real_escape_string($mysqli,$_POST['log_password']);
		$log_password = md5($log_password);
	
	$select_account = mysqli_query($mysqli, "SELECT * FROM `seelog_ocds_account` WHERE account_username = '$username' or account_email = '$username'");
	$check_account = mysqli_num_rows($select_account);
	
	if($check_account==0){
		 $errors['username'] = 'No Email or Username found.'; 
	}
	
	$select_account1 = mysqli_query($mysqli, "SELECT * FROM `seelog_ocds_account` WHERE account_password = '$log_password' and account_username= '$username'");
		$check_account1 = mysqli_num_rows($select_account1);
		if($check_account1==0){
			 $errors['password'] = 'Incorrect Password'; 
		}
// return a response ===========================================================

    // if there are any errors in our errors array, return a success boolean of false
    if ( ! empty($errors)) {

        // if there are items in our errors array, return those errors
        $data['success'] = false;
        $data['errors']  = $errors;
    } else {

        // if there are no errors process our form, then return a message

        // DO ALL YOUR FORM PROCESSING HERE
        // THIS CAN BE WHATEVER YOU WANT TO DO (LOGIN, SAVE, UPDATE, WHATEVER)
		
		
		foreach($select_account1 as $row){
			$_SESSION['username'] = $row['account_username'];
			$_SESSION['priv'] = $row['priv_code'];
			$_SESSION['show'] = $row['show_username'];
			$_SESSION['dp'] = $row['account_avatar'];
			$_SESSION['cover'] = $row['account_cover'];
			$_SESSION['priv'] = $row['priv_code'];
			$success['priv'] = $row['priv_code'];
		}
		

		

        // show a message of success and provide a true success variable
        $data['success'] = $success;
        $data['message'] = 'Success!';
    }

    // return all our data to an AJAX call
    echo json_encode($data);
	
	?>