<?php
include "connect.php";
session_start();
$errors         = array();      // array to hold validation errors
$data           = array();      // array to pass back data

// validate the variables ======================================================
    // if any of these variables don't exist, add an error to our $errors array
	
		$pa= mysqli_real_escape_string($mysqli,$_POST['pa']);
		$qp= mysqli_real_escape_string($mysqli,$_POST['qp']);
		$fd= mysqli_real_escape_string($mysqli,$_POST['fd']);
		$td= mysqli_real_escape_string($mysqli,$_POST['td']);
		$p= mysqli_real_escape_string($mysqli,$_POST['p']);
	
	
// return a response ===========================================================

    // if there are any errors in our errors array, return a success boolean of false
    if ( ! empty($errors)) {

        // if there are items in our errors array, return those errors
        $data['success'] = false;
        $data['errors']  = $errors;
    } else {

        // if there are no errors process our form, then return a message

        // DO ALL YOUR FORM PROCESSING HERE
        // THIS CAN BE WHATEVER YOU WANT TO DO (LOGIN, SAVE, UPDATE, WHATEVER)
		
		
		

		$insert_account = mysqli_query($mysqli,"INSERT INTO `seelog_ocds_account`(`account_fname`, `account_lname`, `account_email`, `account_username`, `account_password`, `account_avatar`, `account_cover`, `priv_code`, `show_username`, `friends`, `post`, `flagged`) VALUES ('$fname','$lname','$email','$email','$password','dp/default.png','cover/default.jpg','user01','0','0','0','0')") or die("Error creating account: " . mysqli_error($mysqli));
		$_SESSION['username'] = $email;
		$_SESSION['priv'] = 'user01';
		$_SESSION['cover'] = 'cover/default.jpg';
		$_SESSION['dp'] = 'dp/default.png';
		$_SESSION['show'] = '0';
		$_SESSION['priv'] = 'user01';
        // show a message of success and provide a true success variable
        $data['success'] = true;
        $data['message'] = 'Success!';
    }

    // return all our data to an AJAX call
    echo json_encode($data);
	
	?>