<?php
$file = $_GET['file'];
$str = file_get_contents('json/'.$file.'');

$json = json_decode($str, true);

$ocid = $json[0]['ocid'];
$final_data = json_encode($json);
if(file_put_contents('json/ '.$ocid.'.json', $final_data))
{
	unlink('json/'.$file.'');
	echo "<script>location.href='../index.php'</script>";
}

?>