<?php
include "../connect.php";

$sql = "SELECT * FROM reply ORDER BY parent_comment_id asc, id asc";

$result = mysqli_query($mysqli, $sql);
$record_set = array();

while ($row = mysqli_fetch_assoc($result)) {
    array_push($record_set, $row);
}
mysqli_free_result($result);

mysqli_close($mysqli);

echo json_encode($record_set);

?>