<?php

		if (file_exists('data1.json'))
		{
			$current_data = file_get_contents('data1.json');
			$array_data =  json_decode($current_data, true);
			
			$extra = (array(
				'ocid' => $_POST["ocid"],
				'id' => '',
				'date' => '',
				'tag' => array(),
				'initiationType' => '',
				'planning' => array(
					'rationale' => $_POST['rationale'],
					)));	
			$array_data[] = $extra;
			$final_data = json_encode($array_data, JSON_PRETTY_PRINT);
			if(file_put_contents('data1.json', $final_data))
			{
				file_put_contents('data.json', $final_data);
				$message = "JSON file save successfully!";
			}
		}
		else
		{
			$error = "JSON File not exist";
		}
	

?>